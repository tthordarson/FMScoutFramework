﻿using System;

namespace FMScoutFramework.Core.Offsets
{
	public sealed class ContractBonusOffsets
	{
		public const short BonusLength = 0x8;
		public const short Value = 0x0;
		public const short Type = 0x4;
	}
}

