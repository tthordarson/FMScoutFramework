﻿using System;
using FMScoutFramework.Core.Entities.GameVersions;
using FMScoutFramework.Core.Managers;
using FMScoutFramework.Defines.Offsets;

namespace FMScoutFramework.Core.Entities.InGame
{
	public class City : BaseObject
	{
		public City (int memoryAddress, IVersion version) 
			: base(memoryAddress, version)
		{	}
		public City (int memoryAddress, ArraySegment<byte> originalBytes, IVersion version) 
			: base(memoryAddress, originalBytes, version)
		{	}

        public int ID
        {
            get
            {
                return PropertyInvoker.Get<Int32>(CityOffsets.ID, OriginalBytes, MemoryAddress, DatabaseMode);
            }
        }

        public string Name
        {
            get
            {
                return PropertyInvoker.GetString(CityOffsets.Name, 0, OriginalBytes, MemoryAddress, DatabaseMode);
            }
        }

        public Nation Nation
        {
            get
            {
                return PropertyInvoker.GetPointer<Nation>(CityOffsets.Nation, OriginalBytes, MemoryAddress, DatabaseMode, Version);
            }
        }
	}
}

